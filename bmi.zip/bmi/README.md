# BMI 계산기

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/Zun-Tun/pen/01a1ae8c-47a3-7d21-861e-56ebab42da9e](https://codepen.io/editor/Zun-Tun/pen/01a1ae8c-47a3-7d21-861e-56ebab42da9e).

